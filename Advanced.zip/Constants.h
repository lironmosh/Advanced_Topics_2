
using namespace std;
class Constants
{

public:
	static const int N = 10;
	static const int M = 10;
	static const int R = 2;
	static const int P = 5;
	static const int S = 1;
	static const int B = 2;
	static const int J = 2;
	static const int F = 1;
	static const int MAX_NO_FIGHTS = 100;
};