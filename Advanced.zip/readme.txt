If both players have flags but ran out of movable pieces
the following error message is printed:
A tie - All moving PIECEs of both players are eaten